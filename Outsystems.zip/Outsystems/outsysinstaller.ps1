# Requires -RunAsAdministrator
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# -----------------------------
# Helper Functions
# -----------------------------
function Run-Script($scriptPath, $arguments="") {
    if (!(Test-Path $scriptPath)) {
        [System.Windows.Forms.MessageBox]::Show("Installer not found: $scriptPath", "Error", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error)
        exit 1
    }

    try {
        $process = Start-Process -FilePath "powershell.exe" -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$scriptPath`" $arguments" -Wait -PassThru -WindowStyle Hidden
        if ($process.ExitCode -ne 0) {
            [System.Windows.Forms.MessageBox]::Show("Failed to install: $scriptPath`nExit code: $($process.ExitCode)", "Error", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error)
            exit 1
        }
    } catch {
        [System.Windows.Forms.MessageBox]::Show("Exception occurred while running: $scriptPath`n$($_.Exception.Message)", "Error", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error)
        exit 1
    }
}

# -----------------------------
# Create Installer Form
# -----------------------------
$form = New-Object System.Windows.Forms.Form
$form.Text = "Platform Server Installer"
$form.Size = New-Object System.Drawing.Size(500,250)
$form.StartPosition = "CenterScreen"

# Label
$label = New-Object System.Windows.Forms.Label
$label.Text = "Step 1: Click Install to install prerequisites."
$label.AutoSize = $true
$label.Location = New-Object System.Drawing.Point(20,20)
$form.Controls.Add($label)

# Step 1 Buttons
$installPrereqBtn = New-Object System.Windows.Forms.Button
$installPrereqBtn.Text = "Install"
$installPrereqBtn.Location = New-Object System.Drawing.Point(50,150)
$installPrereqBtn.Size = New-Object System.Drawing.Size(100,30)
$form.Controls.Add($installPrereqBtn)

$continueBtn1 = New-Object System.Windows.Forms.Button
$continueBtn1.Text = "Continue"
$continueBtn1.Location = New-Object System.Drawing.Point(170,150)
$continueBtn1.Size = New-Object System.Drawing.Size(100,30)
$continueBtn1.Enabled = $false
$form.Controls.Add($continueBtn1)

$cancelBtn1 = New-Object System.Windows.Forms.Button
$cancelBtn1.Text = "Cancel"
$cancelBtn1.Location = New-Object System.Drawing.Point(290,150)
$cancelBtn1.Size = New-Object System.Drawing.Size(100,30)
$form.Controls.Add($cancelBtn1)

# -----------------------------
# Step 2 Controls (Path Selection)
# -----------------------------
$pathLabel = New-Object System.Windows.Forms.Label
$pathLabel.Text = "Step 2: Select installation path for Platform Server"
$pathLabel.AutoSize = $true
$pathLabel.Location = New-Object System.Drawing.Point(20,20)
$pathLabel.Visible = $false
$form.Controls.Add($pathLabel)

$pathTextBox = New-Object System.Windows.Forms.TextBox
$pathTextBox.Size = New-Object System.Drawing.Size(300,25)
$pathTextBox.Location = New-Object System.Drawing.Point(20,60)
$pathTextBox.Text = "C:\Program Files\PlatformServer"
$pathTextBox.Visible = $false
$form.Controls.Add($pathTextBox)

$browseBtn = New-Object System.Windows.Forms.Button
$browseBtn.Text = "Browse"
$browseBtn.Location = New-Object System.Drawing.Point(330,60)
$browseBtn.Size = New-Object System.Drawing.Size(80,25)
$browseBtn.Visible = $false
$form.Controls.Add($browseBtn)

$continueBtn2 = New-Object System.Windows.Forms.Button
$continueBtn2.Text = "Continue"
$continueBtn2.Location = New-Object System.Drawing.Point(50,150)
$continueBtn2.Size = New-Object System.Drawing.Size(100,30)
$continueBtn2.Visible = $false
$form.Controls.Add($continueBtn2)

# Step 3 Controls (Install Platform Server)
$installPlatformBtn = New-Object System.Windows.Forms.Button
$installPlatformBtn.Text = "Install"
$installPlatformBtn.Location = New-Object System.Drawing.Point(50,150)
$installPlatformBtn.Size = New-Object System.Drawing.Size(100,30)
$installPlatformBtn.Visible = $false
$form.Controls.Add($installPlatformBtn)

# -----------------------------
# Button Actions
# -----------------------------
$installPrereqBtn.Add_Click({
    $installPrereqBtn.Enabled = $false
    $label.Text = "Installing prerequisites..."

    $prerequisiteScripts = @(
        "vc_redist.ps1",
        "dotnet_hosting.ps1",
        "IIS_setup.ps1"
    )

    foreach ($script in $prerequisiteScripts) {
        Run-Script $script
    }

    $label.Text = "Prerequisites installed successfully. Click Continue."
    $continueBtn1.Enabled = $true
})

$continueBtn1.Add_Click({
    # Hide Step 1 controls
    $installPrereqBtn.Visible = $false
    $continueBtn1.Visible = $false
    $cancelBtn1.Visible = $false

    # Show Step 2 controls
    $label.Visible = $false
    $pathLabel.Visible = $true
    $pathTextBox.Visible = $true
    $browseBtn.Visible = $true
    $continueBtn2.Visible = $true
})

$browseBtn.Add_Click({
    $folderBrowser = New-Object System.Windows.Forms.FolderBrowserDialog
    $folderBrowser.Description = "Select installation folder for Platform Server"
    $folderBrowser.SelectedPath = $pathTextBox.Text
    if ($folderBrowser.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        $pathTextBox.Text = $folderBrowser.SelectedPath
    }
})

$continueBtn2.Add_Click({
    # Hide Step 2 controls
    $pathLabel.Visible = $false
    $pathTextBox.Visible = $false
    $browseBtn.Visible = $false
    $continueBtn2.Visible = $false

    # Show Step 3 controls
    $installPlatformBtn.Visible = $true
    $label.Text = "Step 3: Click Install to install Platform Server"
    $label.Visible = $true
})

$installPlatformBtn.Add_Click({
    $installPlatformBtn.Enabled = $false
    $label.Text = "Installing Platform Server..."
    $installPath = $pathTextBox.Text

    $platformInstaller = "platformServer.ps1"
    Run-Script $platformInstaller "-installPath `"$installPath`""

    [System.Windows.Forms.MessageBox]::Show("Platform Server installed successfully!", "Success", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information)
    $form.Close()
})

$cancelBtn1.Add_Click({
    $form.Close()
})

# -----------------------------
# Show Form
# -----------------------------
[void]$form.ShowDialog()
