# PowerShell Script to Install Microsoft .NET 8.0 Windows Server Hosting Bundle
# Assumes the installer (dotnet-hosting-8.0.x-win.exe) is in the same folder as this script

$installerName = "dotnet-hosting-8.0.18-win.exe"   # Update if your filename differs
$installerPath = Join-Path $PSScriptRoot $installerName

# Function to check if .NET 8 Hosting Bundle is installed
function Test-DotNetHostingInstalled {
    $isInstalled = $false
    $registryPaths = @(
        "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*",
        "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*"
    )

    foreach ($path in $registryPaths) {
        $apps = Get-ItemProperty $path -ErrorAction SilentlyContinue | Where-Object {
            $_.DisplayName -like "Microsoft .NET 8.0 ASP.NET Core*" -or
            $_.DisplayName -like "Microsoft .NET 8.0 Windows Server Hosting*"
        }
        if ($apps) {
            $isInstalled = $true
            break
        }
    }

    return $isInstalled
}

if (Test-DotNetHostingInstalled) {
    Write-Host ".NET 8.0 Windows Server Hosting is already installed. Skipping installation."
    exit 0
}

if (-Not (Test-Path $installerPath)) {
    Write-Host "Installer not found: $installerPath"
    exit 1
}

Write-Host "Installing Microsoft .NET 8.0 Windows Server Hosting..."
$process = Start-Process -FilePath $installerPath -ArgumentList "/quiet", "/norestart" -Wait -PassThru

switch ($process.ExitCode) {
    0 { Write-Host "Installation completed successfully." }
    3010 { Write-Host "Installation succeeded, but a restart is required." }
    default { Write-Host "Installation failed with exit code $($process.ExitCode)." }
}
