<# 
.SYNOPSIS
  Installs IIS (with specific role services) and Windows Process Activation Service.

.NOTES
  Tested on Windows Server 2016/2019/2022.
  Run from an elevated PowerShell session (Admin). If you’ll convert with ps2exe, you can also use -requireAdmin.
#>

#region --- Safety & prerequisites ---
# Ensure ServerManager module is available (Windows Server)
if (-not (Get-Module -ListAvailable -Name ServerManager)) {
    Write-Error "ServerManager module not found. This script targets Windows Server (Install-WindowsFeature)."
    exit 1
}
Import-Module ServerManager -ErrorAction Stop
#endregion

#region --- Feature selections mapped to your UI steps ---
# IIS + role services
$iisFeatures = @(
    # Parent
    'Web-Server'                             # Web Server (IIS)

    # Common HTTP Features
    'Web-Common-Http','Web-Default-Doc','Web-Dir-Browsing','Web-Http-Errors','Web-Static-Content'

    # Health and Diagnostics
    'Web-Health','Web-Http-Logging','Web-Request-Monitor'

    # Performance
    'Web-Performance','Web-Stat-Compression','Web-Dyn-Compression'

    # Security
    'Web-Security','Web-Filtering','Web-Windows-Auth'   # Request Filtering, Windows Authentication

    # Application Development (.NET)
    'Web-App-Dev','Web-Net-Ext45','Web-Asp-Net45','Web-ISAPI-Ext','Web-ISAPI-Filter'

    # Management Tools
    'Web-Mgmt-Tools','Web-Mgmt-Console','Web-Mgmt-Compat','Web-Metabase'  # IIS 6 Metabase Compatibility
)

# .NET Framework 4.x (ASP.NET 4.x relies on these; usually auto-added, but we include explicitly for clarity)
$dotNetFeatures = @(
    'NET-Framework-45-Features','NET-Framework-45-Core','NET-Framework-45-ASPNET'
)

# Windows Process Activation Service (WAS)
$wasFeatures = @(
    'WAS','WAS-Config-APIs','WAS-Process-Model'
)
#endregion

#region --- Install ---
$allFeatures = $dotNetFeatures + $iisFeatures + $wasFeatures

Write-Host "Installing required Windows features..." -ForegroundColor Cyan
try {
    $result = Install-WindowsFeature -Name $allFeatures -IncludeManagementTools -ErrorAction Stop -Verbose
}
catch {
    Write-Error "Feature installation failed: $($_.Exception.Message)"
    exit 1
}

# Summaries
Write-Host "`n==== Installation Summary ====" -ForegroundColor Cyan
Write-Host ("Successes : {0}" -f ($result.Success -as [bool]))
Write-Host ("Installed : {0}" -f ($result.Installed.Count))
Write-Host ("Restart   : {0}" -f ($result.RestartNeeded))
if ($result.Installed -and $result.Installed.Count -gt 0) {
    Write-Host "`nNewly installed features:" -ForegroundColor Green
    $result.Installed | ForEach-Object { Write-Host "  - $($_.Name)" }
}

# List any still missing (should be none, but helpful if DISM source/WSUS policies block some)
$missing = $allFeatures | Where-Object { (Get-WindowsFeature $_).InstallState -ne 'Installed' }
if ($missing) {
    Write-Warning "`nThe following features are not installed (check payload/sources or policies):"
    $missing | ForEach-Object { Write-Host "  - $_" }
}
else {
    Write-Host "`nAll requested IIS and WAS components are installed." -ForegroundColor Green
}

Write-Host ""
Write-Host "If prompted by the system that a restart is required, please restart the server." -ForegroundColor Yellow
#endregion
