# Looks for vc_redist.x64.exe in the same folder as this script
$installerPath = Join-Path $PSScriptRoot "vc_redist.x64.exe"

# Function to check if Visual C++ 2015-2022 x64 is installed
function Test-VCRedistributableInstalled {
    $vcInstalled = $false
    $registryPaths = @(
        "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*",
        "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*"
    )

    foreach ($path in $registryPaths) {
        $apps = Get-ItemProperty $path -ErrorAction SilentlyContinue | Where-Object {
            $_.DisplayName -like "Microsoft Visual C++ 2015-2022 Redistributable (x64)*"
        }
        if ($apps) {
            $vcInstalled = $true
            break
        }
    }

    return $vcInstalled
}

if (Test-VCRedistributableInstalled) {
    Write-Host "Microsoft Visual C++ 2015-2022 Redistributable (x64) is already installed. Skipping installation."
    exit 0
}

if (-Not (Test-Path $installerPath)) {
    Write-Host "Installer not found in script directory: $installerPath"
    exit 1
}

Write-Host "Installing Microsoft Visual C++ 2015-2022 Redistributable (x64)..."
$process = Start-Process -FilePath $installerPath -ArgumentList "/install", "/quiet", "/norestart" -Wait -PassThru

switch ($process.ExitCode) {
    0 { Write-Host "Installation completed successfully." }
    3010 { Write-Host "Installation succeeded, but a restart is required." }
    default { Write-Host "Installation failed with exit code $($process.ExitCode)." }
}
