<#
.SYNOPSIS
    Semi-attended OutSystems Platform installer package
#>

# --- Logging ---
param (
    [string]$installPath="C:\Program Files\OutSystems\Platform Server"
)

function Write-Log {
    param([string]$Message)
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Write-Host "[$timestamp] $Message"
}

function Run-Installer {
    param(
        [string]$ExePath,
        [string]$Arguments
    )
    if (!(Test-Path $ExePath)) {
        Write-Log "ERROR: Installer not found: $ExePath"
        exit 1
    }

    Write-Log "Running: $ExePath $Arguments"
    $process = Start-Process -FilePath $ExePath -ArgumentList $Arguments -Wait -PassThru
    $exitCode = $process.ExitCode
    switch ($exitCode) {
        0 {
            Write-Log "Successfully Installed the platform server"
        }
        1 {
           Write-Log "system reboot is required to finalize prerequisite installation 
           (only detected when the Platform Server installation package is automatically installing the prerequisites)"
        }
        
        default {Write-Log "ERROR: Installer failed"}
    }
}

# --- Prompt install path ---
#$defaultInstallPath = "C:\Program Files\OutSystems\Platform Server"
#$installPath = Read-Host "Enter installation path (default: $defaultInstallPath)"
#if ([string]::IsNullOrWhiteSpace($installPath)) {
#    $installPath = $defaultInstallPath
#}

if ($PSScriptRoot) {
    $BaseDir = $PSScriptRoot
} else {
    $BaseDir = Split-Path -Parent $MyInvocation.MyCommand.Definition
}

if ($installPath) {
    $defaultInstallPath = $installPath
}
#Write-Log "Installation path set to: $defaultInstallPath"

# --- Install OutSystems Platform Server (semi-attended) ---
$outSystemsInstaller = Join-Path $BaseDir "PlatformServer-11.37.0 (Build 45622).exe"
$outSystemsArgs = "/S /InstallPrerequisites=True /DoTuning=131072 /D=$installPath"  # keep semi-attended
Run-Installer -ExePath $outSystemsInstaller -Arguments $outSystemsArgs
